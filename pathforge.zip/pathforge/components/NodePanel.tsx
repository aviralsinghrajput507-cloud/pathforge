"use client";

import { useEffect, useState } from "react";
import { postJson } from "@/lib/api";
import { TYPE_COLORS, TYPE_LABELS, type NodeDetail, type RNode, type Status } from "@/lib/types";

const cache = new Map<string, NodeDetail>();

export default function NodePanel({
  goal,
  node,
  status,
  busy,
  onToggle,
  onClose,
}: {
  goal: string;
  node: RNode;
  status: Status;
  busy: boolean;
  onToggle: () => void;
  onClose: () => void;
}) {
  const key = `${goal}|${node.title}`;
  const [detail, setDetail] = useState<NodeDetail | null>(cache.get(key) ?? null);
  const [loading, setLoading] = useState(!cache.has(key));
  const [err, setErr] = useState("");
  const [tries, setTries] = useState(0);

  useEffect(() => {
    const hit = cache.get(key);
    if (hit) {
      setDetail(hit);
      setLoading(false);
      setErr("");
      return;
    }
    let live = true;
    setDetail(null);
    setLoading(true);
    setErr("");
    postJson<NodeDetail>("/api/node", { goal, title: node.title, type: node.type, description: node.description })
      .then((d) => {
        if (!live) return;
        cache.set(key, d);
        setDetail(d);
      })
      .catch((e: Error) => live && setErr(e.message))
      .finally(() => live && setLoading(false));
    return () => {
      live = false;
    };
  }, [key, tries, goal, node.title, node.type, node.description]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  return (
    <aside className="panel" aria-label={`Details for ${node.title}`}>
      <button className="btn ghost close" onClick={onClose} aria-label="Close details">✕</button>
      <span className="chip" style={{ background: TYPE_COLORS[node.type] }}>{TYPE_LABELS[node.type]}</span>
      <h2>{node.title}</h2>
      <p className="muted">{node.phase} · {node.months ? `about ${node.months} months` : "ongoing"}</p>
      <p>{node.description}</p>
      {status === "locked" && <p className="note">🔒 Locked: finish the earlier steps (or mark them known) to unlock it.</p>}

      <button className="btn primary wide" onClick={onToggle} disabled={busy}>
        {busy ? "Re-routing roadmap…" : status === "done" ? "↩ Mark as not known" : "✅ I already know this"}
      </button>

      <div className="aibox" aria-live="polite">
        <p className="muted small">🤖 AI-generated advice. Verify links and facts before relying on them.</p>
        {loading && <p>Generating tailored advice…</p>}
        {err && (
          <p role="alert" className="error">
            {err} <button className="btn" onClick={() => setTries((t) => t + 1)}>Retry</button>
          </p>
        )}
        {detail && (
          <>
            <h3>Weekend project</h3>
            <p><strong>{detail.project.title}</strong></p>
            <p>{detail.project.description}</p>
            <h3>GitHub repo to study</h3>
            <p>
              <a href={`https://github.com/search?q=${encodeURIComponent(detail.repo.name)}`} target="_blank" rel="noopener noreferrer">{detail.repo.name}</a>
              <br />
              <span className="muted">{detail.repo.why}</span>
            </p>
            <h3>Interview questions</h3>
            <ol>{detail.questions.map((q, i) => <li key={i}>{q}</li>)}</ol>
          </>
        )}
      </div>
    </aside>
  );
}
