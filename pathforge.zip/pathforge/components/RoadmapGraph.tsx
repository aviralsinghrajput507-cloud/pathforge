"use client";

import { useMemo } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Handle,
  Position,
  type Node,
  type Edge,
  type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { TYPE_COLORS, TYPE_LABELS, type Roadmap, type RNode, type Status } from "@/lib/types";
import { positions, statuses } from "@/lib/graph";

type StepData = { n: RNode; status: Status; selected: boolean; onSelect: (id: string) => void };
type StepNode = Node<StepData, "step">;

function StepView({ data }: NodeProps<StepNode>) {
  const { n, status, selected, onSelect } = data;
  const icon = status === "done" ? "✅" : status === "locked" ? "🔒" : "▶";
  return (
    <>
      <Handle type="target" position={Position.Left} isConnectable={false} />
      <button
        type="button"
        className={`step ${status}${selected ? " sel" : ""}`}
        style={{ borderColor: TYPE_COLORS[n.type] }}
        onClick={() => onSelect(n.id)}
        aria-label={`${n.title}. ${TYPE_LABELS[n.type]}. ${status}. Press to open details.`}
      >
        <span className="step-top">
          <span className="chip" style={{ background: TYPE_COLORS[n.type] }}>{TYPE_LABELS[n.type]}</span>
          <span aria-hidden>{icon}</span>
        </span>
        <strong>{n.title}</strong>
        <small>{n.months ? `~${n.months} mo` : "ongoing"} · {n.phase}</small>
      </button>
      <Handle type="source" position={Position.Right} isConnectable={false} />
    </>
  );
}

const nodeTypes = { step: StepView };

export default function RoadmapGraph({
  rm,
  selectedId,
  onSelect,
  fitKey,
}: {
  rm: Roadmap;
  selectedId: string | null;
  onSelect: (id: string) => void;
  fitKey: number;
}) {
  const { nodes, edges } = useMemo(() => {
    const st = statuses(rm);
    const pos = positions(rm.nodes);
    const nodes: StepNode[] = rm.nodes.map((n) => ({
      id: n.id,
      type: "step",
      position: pos[n.id],
      draggable: false,
      data: { n, status: st[n.id], selected: selectedId === n.id, onSelect },
    }));
    const edges: Edge[] = rm.edges.map((e) => ({
      id: `${e.source}-${e.target}`,
      source: e.source,
      target: e.target,
      animated: st[e.source] === "done" && st[e.target] === "available",
      style: { stroke: st[e.source] === "done" ? "#4ade80" : "#475569", strokeWidth: 2 },
    }));
    return { nodes, edges };
  }, [rm, selectedId, onSelect]);

  return (
    <ReactFlow
      key={fitKey}
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      colorMode="dark"
      fitView
      fitViewOptions={{ padding: 0.15 }}
      minZoom={0.15}
      maxZoom={2}
      nodesConnectable={false}
      nodesDraggable={false}
      elementsSelectable={false}
    >
      <Background gap={24} />
      <Controls showInteractive={false} />
      <MiniMap pannable zoomable nodeColor={(n) => TYPE_COLORS[(n.data as StepData).n.type]} className="minimap" />
    </ReactFlow>
  );
}
