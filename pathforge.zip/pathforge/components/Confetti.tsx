"use client";

import { useMemo } from "react";

export default function Confetti() {
  const bits = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => ({
        e: ["🎉", "✨", "⭐", "🚀"][i % 4],
        left: Math.random() * 100,
        delay: Math.random() * 0.4,
      })),
    []
  );
  return (
    <div aria-hidden>
      {bits.map((b, i) => (
        <span key={i} className="confetti" style={{ left: `${b.left}vw`, animationDelay: `${b.delay}s` }}>{b.e}</span>
      ))}
    </div>
  );
}
