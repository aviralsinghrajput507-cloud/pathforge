import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "PathForge – AI Career Roadmapper",
  description: "Turn a hyper-specific dream job into an interactive, AI-generated career skill tree.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a className="skip" href="#main">Skip to content</a>
        <header className="topbar">
          <Link href="/" className="brand">Path<span>Forge</span></Link>
          <span className="ainote">🤖 You are talking to AI (Google Gemini)</span>
        </header>
        <div id="main">{children}</div>
      </body>
    </html>
  );
}
