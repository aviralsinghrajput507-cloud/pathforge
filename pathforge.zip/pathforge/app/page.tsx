"use client";

import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { list, remove } from "@/lib/store";
import { statuses } from "@/lib/graph";
import { TYPE_COLORS, TYPE_LABELS, type NodeType, type Roadmap } from "@/lib/types";

const EXAMPLES = [
  "Full Stack Developer at a climate tech startup",
  "UI/UX Designer for fintech apps",
  "Machine Learning Engineer at a healthcare company",
  "Cybersecurity Analyst at a bank",
];
const TYPES: NodeType[] = ["skill", "role", "project", "cert"];

export default function Dashboard() {
  const router = useRouter();
  const [maps, setMaps] = useState<Roadmap[]>([]);
  const [ready, setReady] = useState(false);
  const [goal, setGoal] = useState("");
  const [err, setErr] = useState("");
  const [armed, setArmed] = useState<string | null>(null);

  useEffect(() => {
    setMaps(list());
    setReady(true);
  }, []);

  function start(e: FormEvent) {
    e.preventDefault();
    const g = goal.trim();
    if (g.length < 4) return setErr("Please describe your dream job in at least 4 characters.");
    if (g.length > 120) return setErr("Keep it under 120 characters.");
    router.push(`/roadmap?new=${encodeURIComponent(g)}`);
  }

  const total = maps.reduce((a, m) => a + m.nodes.length, 0);
  const done = maps.reduce((a, m) => a + m.nodes.filter((n) => m.done[n.id]).length, 0);
  const monthsLeft = maps.reduce((a, m) => a + m.nodes.filter((n) => !m.done[n.id]).reduce((s, n) => s + n.months, 0), 0);
  const byType = TYPES.map((t) => {
    const all = maps.flatMap((m) => m.nodes.filter((n) => n.type === t).map((n) => !!m.done[n.id]));
    return { t, total: all.length, done: all.filter(Boolean).length };
  });
  const upNext = maps.flatMap((m) => {
    const st = statuses(m);
    return m.nodes.filter((n) => st[n.id] === "available").slice(0, 2).map((n) => ({ goal: m.goal, title: n.title, type: n.type }));
  });

  return (
    <main className="container">
      <section className="card hero">
        <h1>What&apos;s your dream job?</h1>
        <p className="muted">Be hyper-specific. AI reverse-engineers it into an interactive roadmap you can zoom, pan and click.</p>
        <form onSubmit={start} className="row">
          <label htmlFor="goal" className="sr">Dream job</label>
          <input id="goal" className="input" maxLength={120} value={goal} onChange={(e) => { setGoal(e.target.value); setErr(""); }} placeholder="e.g. Full Stack Developer at a climate tech startup" aria-invalid={!!err} aria-describedby={err ? "goal-err" : undefined} />
          <button className="btn primary" type="submit">Generate roadmap</button>
        </form>
        {err && <p id="goal-err" role="alert" className="error">{err}</p>}
        <div className="chips">
          {EXAMPLES.map((x) => (
            <button key={x} type="button" className="btn small" onClick={() => { setGoal(x); setErr(""); }}>{x}</button>
          ))}
        </div>
      </section>

      <h2>Your dashboard</h2>
      <section className="stats" aria-label="Summary">
        <div className="card stat"><b>{maps.length}</b><span>Roadmaps</span></div>
        <div className="card stat"><b>{done}/{total}</b><span>Milestones done</span></div>
        <div className="card stat"><b>{total ? Math.round((done * 100) / total) : 0}%</b><span>Overall progress</span></div>
        <div className="card stat"><b>~{monthsLeft}</b><span>Months remaining</span></div>
      </section>

      <section className="two">
        <div className="card">
          <h3>Progress by type</h3>
          {byType.map(({ t, total: tt, done: dd }) => (
            <div key={t}>
              <div className="between"><span>{TYPE_LABELS[t]}s</span><span>{dd}/{tt}</span></div>
              <div className="bar" role="progressbar" aria-valuemin={0} aria-valuemax={tt} aria-valuenow={dd} aria-label={`${TYPE_LABELS[t]} progress`}>
                <i style={{ width: `${tt ? (dd * 100) / tt : 0}%`, background: TYPE_COLORS[t] }} />
              </div>
            </div>
          ))}
        </div>
        <div className="card">
          <h3>Up next</h3>
          {upNext.length === 0 && <p className="muted">Nothing yet. Generate a roadmap to get started.</p>}
          {upNext.slice(0, 6).map((u, i) => (
            <p key={i} className="upnext"><strong>{u.title}</strong><br /><span className="muted small">{u.goal} · {TYPE_LABELS[u.type]}</span></p>
          ))}
        </div>
      </section>

      <h2>Your roadmaps</h2>
      {ready && maps.length === 0 && <p className="card muted center">No roadmaps yet. Generate your first one above.</p>}
      <section className="maps">
        {maps.map((m) => {
          const d = m.nodes.filter((n) => m.done[n.id]).length;
          const pct = Math.round((d * 100) / m.nodes.length);
          const next = m.nodes.find((n) => statuses(m)[n.id] === "available");
          return (
            <article key={m.id} className="card">
              <h4>{m.goal}</h4>
              <div className="between"><span>{d}/{m.nodes.length} milestones</span><span>{pct}%</span></div>
              <div className="bar"><i style={{ width: `${pct}%` }} /></div>
              <p className="muted small">{next ? `Next: ${next.title}` : "All done 🎉"}</p>
              <div className="row">
                <Link className="btn primary" href={`/roadmap?id=${m.id}`}>Open</Link>
                <button className="btn" onClick={() => { if (armed === m.id) { remove(m.id); setMaps(list()); setArmed(null); } else setArmed(m.id); }}>
                  {armed === m.id ? "Confirm delete" : "Delete"}
                </button>
              </div>
            </article>
          );
        })}
      </section>
    </main>
  );
}
