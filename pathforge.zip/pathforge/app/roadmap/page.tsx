"use client";

import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import RoadmapGraph from "@/components/RoadmapGraph";
import NodePanel from "@/components/NodePanel";
import Confetti from "@/components/Confetti";
import { postJson } from "@/lib/api";
import { get, save } from "@/lib/store";
import { statuses } from "@/lib/graph";
import type { GenResult, Roadmap } from "@/lib/types";

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function Inner() {
  const sp = useSearchParams();
  const id = sp.get("id");
  const goalParam = sp.get("new");

  const [rm, setRm] = useState<Roadmap | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [error, setError] = useState("");
  const [sel, setSel] = useState<string | null>(null);
  const [showPaths, setShowPaths] = useState(false);
  const [rerouting, setRerouting] = useState(false);
  const [toast, setToast] = useState("");
  const [burst, setBurst] = useState(0);
  const [fitKey, setFitKey] = useState(0);
  const ref = useRef<Roadmap | null>(null);
  const req = useRef(0);

  const commit = useCallback((next: Roadmap) => {
    ref.current = next;
    setRm(next);
    save(next);
  }, []);

  const build = useCallback(async (goal: string) => {
    setState("loading");
    setError("");
    try {
      const data = await postJson<GenResult>("/api/roadmap", { goal, known: [] });
      const done: Record<string, boolean> = {};
      data.nodes.forEach((n) => n.known && (done[n.id] = true));
      const next: Roadmap = { ...data, id: newId(), goal, done, updatedAt: Date.now() };
      commit(next);
      setFitKey((k) => k + 1);
      setState("ready");
      window.history.replaceState(null, "", `/roadmap?id=${next.id}`);
    } catch (e) {
      setError((e as Error).message);
      setState("error");
    }
  }, [commit]);

  useEffect(() => {
    if (id) {
      if (ref.current?.id === id) return;
      const found = get(id);
      if (found) {
        ref.current = found;
        setRm(found);
        setFitKey((k) => k + 1);
        setState("ready");
      } else {
        setError("This roadmap was not found on this device.");
        setState("error");
      }
    } else if (goalParam && !ref.current) {
      build(goalParam);
    } else if (!goalParam) {
      setError("No goal given. Go back and describe your dream job.");
      setState("error");
    }
  }, [id, goalParam, build]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 4000);
    return () => clearTimeout(t);
  }, [toast]);

  const select = useCallback((nid: string) => {
    setShowPaths(false);
    setSel(nid);
  }, []);

  async function toggle(nodeId: string) {
    const cur = ref.current;
    if (!cur) return;
    const was = !!cur.done[nodeId];
    const done = { ...cur.done };
    if (was) delete done[nodeId];
    else done[nodeId] = true;
    const next = { ...cur, done, updatedAt: Date.now() };
    commit(next);
    req.current++; // cancels any in-flight re-route
    if (was) return setRerouting(false);

    setBurst((b) => b + 1);
    const node = cur.nodes.find((n) => n.id === nodeId)!;
    if (cur.nodes.every((n) => done[n.id])) return setToast("Roadmap complete! 🏆");
    const phaseDone = cur.nodes.filter((n) => n.phase === node.phase).every((n) => done[n.id]);
    setToast(phaseDone ? `Phase complete: ${node.phase} 🎉` : `Nice, "${node.title}" is done. Re-routing…`);

    const mine = req.current;
    setRerouting(true);
    try {
      const knownTitles = next.nodes.filter((n) => done[n.id]).map((n) => n.title);
      const data = await postJson<GenResult>("/api/roadmap", { goal: cur.goal, known: knownTitles });
      if (mine !== req.current) return;
      const lower = new Set(knownTitles.map((t) => t.toLowerCase()));
      const nd: Record<string, boolean> = {};
      data.nodes.forEach((n) => (n.known || lower.has(n.title.toLowerCase())) && (nd[n.id] = true));
      commit({ ...next, nodes: data.nodes, edges: data.edges, paths: data.paths.length ? data.paths : next.paths, done: nd, updatedAt: Date.now() });
      setFitKey((k) => k + 1);
      setSel(null);
      setToast("Roadmap re-routed around what you already know ✨");
    } catch {
      if (mine === req.current) setToast("Couldn't re-route right now. Your progress is saved.");
    } finally {
      if (mine === req.current) setRerouting(false);
    }
  }

  if (state === "loading")
    return <div className="center pad" role="status"><p className="spinner">🧠 AI is reverse-engineering your path…</p><p className="muted">This takes 10 to 30 seconds.</p></div>;
  if (state === "error" || !rm)
    return (
      <div className="center pad" role="alert">
        <p className="error">{error}</p>
        {goalParam && <button className="btn primary" onClick={() => build(goalParam)}>Try again</button>}{" "}
        <Link className="btn" href="/">Back to dashboard</Link>
      </div>
    );

  const st = statuses(rm);
  const doneCount = rm.nodes.filter((n) => rm.done[n.id]).length;
  const pct = Math.round((doneCount * 100) / rm.nodes.length);
  const node = rm.nodes.find((n) => n.id === sel);

  return (
    <div className="rmpage">
      <div className="rmhead">
        <Link href="/" className="btn small">← Dashboard</Link>
        <h1 className="rmtitle">{rm.goal}</h1>
        <div className="prog">
          <span>{doneCount}/{rm.nodes.length}</span>
          <div className="bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Roadmap progress"><i style={{ width: `${pct}%` }} /></div>
        </div>
        {rm.paths.length > 0 && <button className="btn small" onClick={() => { setSel(null); setShowPaths((s) => !s); }}>Typical paths</button>}
      </div>

      <div className="graph">
        <RoadmapGraph rm={rm} selectedId={sel} onSelect={select} fitKey={fitKey} />
        <p className="hint" aria-hidden>Drag to pan · scroll or pinch to zoom · tap a node</p>
        {rerouting && <div className="banner" role="status">Re-routing roadmap…</div>}

        {node && <NodePanel key={node.id} goal={rm.goal} node={node} status={st[node.id]} busy={rerouting} onToggle={() => toggle(node.id)} onClose={() => setSel(null)} />}

        {showPaths && (
          <aside className="panel" aria-label="Typical paths">
            <button className="btn ghost close" onClick={() => setShowPaths(false)} aria-label="Close">✕</button>
            <h2>Typical paths</h2>
            <p className="muted small">🤖 AI-generated illustrative archetypes (composites, not real people).</p>
            {rm.paths.map((p, i) => (
              <div key={i} className="aibox">
                <h3>{p.label}</h3>
                <p>{p.steps.join("  →  ")}</p>
                {p.sideProjects.length > 0 && <><p className="muted small">Side projects along the way</p><ul>{p.sideProjects.map((s, j) => <li key={j}>{s}</li>)}</ul></>}
              </div>
            ))}
          </aside>
        )}
      </div>

      {burst > 0 && <Confetti key={burst} />}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}

export default function RoadmapPage() {
  return (
    <Suspense fallback={<div className="center pad">Loading…</div>}>
      <Inner />
    </Suspense>
  );
}
