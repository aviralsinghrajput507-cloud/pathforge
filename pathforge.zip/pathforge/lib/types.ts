export type NodeType = "skill" | "role" | "project" | "cert";
export type Status = "done" | "available" | "locked";

export type RNode = {
  id: string;
  title: string;
  phase: string;
  type: NodeType;
  months: number;
  description: string;
  known?: boolean;
};
export type REdge = { source: string; target: string };
export type TypicalPath = { label: string; steps: string[]; sideProjects: string[] };

export type GenResult = { nodes: RNode[]; edges: REdge[]; paths: TypicalPath[] };
export type Roadmap = GenResult & {
  id: string;
  goal: string;
  done: Record<string, boolean>;
  updatedAt: number;
};

export type NodeDetail = {
  project: { title: string; description: string };
  repo: { name: string; why: string };
  questions: string[];
};

export const TYPE_COLORS: Record<NodeType, string> = {
  skill: "#60a5fa",
  role: "#a78bfa",
  project: "#fb923c",
  cert: "#2dd4bf",
};
export const TYPE_LABELS: Record<NodeType, string> = {
  skill: "Skill",
  role: "Role",
  project: "Project",
  cert: "Certification",
};
