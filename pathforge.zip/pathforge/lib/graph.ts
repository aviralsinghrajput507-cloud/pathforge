import type { Roadmap, RNode, Status } from "./types";

export function statuses(rm: Pick<Roadmap, "nodes" | "edges" | "done">): Record<string, Status> {
  const parents: Record<string, string[]> = {};
  for (const e of rm.edges) {
    if (!parents[e.target]) parents[e.target] = [];
    parents[e.target].push(e.source);
  }
  const out: Record<string, Status> = {};
  for (const n of rm.nodes) {
    if (rm.done[n.id]) out[n.id] = "done";
    else out[n.id] = (parents[n.id] ?? []).every((p) => rm.done[p]) ? "available" : "locked";
  }
  return out;
}

export const COL_W = 300;
export const ROW_H = 112;

export function phaseList(nodes: RNode[]): string[] {
  const p: string[] = [];
  for (const n of nodes) if (!p.includes(n.phase)) p.push(n.phase);
  return p;
}

export function positions(nodes: RNode[]): Record<string, { x: number; y: number }> {
  const phases = phaseList(nodes);
  const counts = phases.map((p) => nodes.filter((n) => n.phase === p).length);
  const max = Math.max(...counts, 1);
  const seen: number[] = phases.map(() => 0);
  const out: Record<string, { x: number; y: number }> = {};
  for (const n of nodes) {
    const c = phases.indexOf(n.phase);
    out[n.id] = { x: c * COL_W, y: seen[c] * ROW_H + ((max - counts[c]) * ROW_H) / 2 };
    seen[c]++;
  }
  return out;
}
