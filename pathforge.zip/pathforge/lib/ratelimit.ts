const hits = new Map<string, number[]>();

/** Tiny in-memory limiter (per server instance). Returns true when over the limit. */
export function limited(key: string, max = 20, windowMs = 60_000): boolean {
  const now = Date.now();
  const arr = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  arr.push(now);
  hits.set(key, arr);
  return arr.length > max;
}
