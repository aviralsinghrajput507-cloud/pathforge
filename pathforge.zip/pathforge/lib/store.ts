import type { Roadmap } from "./types";

const KEY = "pathforge:v1";

export function list(): Roadmap[] {
  if (typeof window === "undefined") return [];
  try {
    const a = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(a) ? a : [];
  } catch {
    return [];
  }
}
function write(a: Roadmap[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(a.slice(0, 20)));
  } catch {}
}
export function get(id: string): Roadmap | undefined {
  return list().find((r) => r.id === id);
}
export function save(r: Roadmap) {
  write([r, ...list().filter((x) => x.id !== r.id)]);
}
export function remove(id: string) {
  write(list().filter((x) => x.id !== id));
}
