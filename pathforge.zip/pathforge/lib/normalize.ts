import { clean } from "./validate";
import type { GenResult, NodeType, RNode, REdge, TypicalPath } from "./types";

const TYPES: NodeType[] = ["skill", "role", "project", "cert"];

/** Turns untrusted AI JSON into a safe, acyclic graph. Throws if unusable. */
export function normalize(raw: any): GenResult {
  if (!raw || !Array.isArray(raw.nodes) || raw.nodes.length < 4) throw new Error("too few nodes");

  const idMap = new Map<string, string>();
  const nodes: RNode[] = raw.nodes.slice(0, 18).map((n: any, i: number) => {
    const id = `n${i + 1}`;
    idMap.set(String(n?.id ?? id), id);
    const months = Number(n?.months);
    return {
      id,
      title: clean(n?.title, 60) || `Step ${i + 1}`,
      phase: clean(n?.phase, 30) || "Phase 1",
      type: TYPES.includes(n?.type) ? n.type : "skill",
      months: Number.isFinite(months) ? Math.min(24, Math.max(0, Math.round(months))) : 1,
      description: clean(n?.description, 180),
      known: n?.known === true,
    } as RNode;
  });

  const index = new Map(nodes.map((n, i) => [n.id, i]));
  const seen = new Set<string>();
  const edges: REdge[] = [];
  for (const e of Array.isArray(raw.edges) ? raw.edges : []) {
    const s = idMap.get(String(e?.source));
    const t = idMap.get(String(e?.target));
    if (!s || !t) continue;
    // Only forward edges (prerequisite listed before dependent) => no cycles.
    if ((index.get(s) ?? 0) >= (index.get(t) ?? 0)) continue;
    const key = `${s}>${t}`;
    if (seen.has(key)) continue;
    seen.add(key);
    edges.push({ source: s, target: t });
  }
  // Every node except the first needs a prerequisite so nothing floats unreachable.
  nodes.forEach((n, i) => {
    if (i > 0 && !edges.some((e) => e.target === n.id)) edges.push({ source: nodes[i - 1].id, target: n.id });
  });

  const paths: TypicalPath[] = (Array.isArray(raw.paths) ? raw.paths : []).slice(0, 3).map((p: any) => ({
    label: clean(p?.label, 80) || "Typical path",
    steps: (Array.isArray(p?.steps) ? p.steps : []).slice(0, 8).map((s: any) => clean(s, 70)).filter(Boolean),
    sideProjects: (Array.isArray(p?.sideProjects) ? p.sideProjects : []).slice(0, 5).map((s: any) => clean(s, 90)).filter(Boolean),
  }));

  return { nodes, edges, paths };
}
