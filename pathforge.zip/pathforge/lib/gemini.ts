export class AiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

const FALLBACKS = ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-2.5-flash"];

function modelList(): string[] {
  const list = [process.env.GEMINI_MODEL, ...FALLBACKS].filter((m): m is string => !!m);
  return Array.from(new Set(list));
}

function parseJson(text: string): any {
  const t = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  return JSON.parse(t);
}

/** Calls Gemini and returns parsed JSON. Tries fallback models if one is unavailable. */
export async function askGemini(prompt: string): Promise<any> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new AiError(500, "Server is missing GEMINI_API_KEY.");

  let lastStatus = 502;
  for (const model of modelList()) {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": key },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: "application/json", temperature: 0.7 },
          }),
          signal: AbortSignal.timeout(50_000),
        }
      );
      if (res.status === 401 || res.status === 403) throw new AiError(500, "Gemini API key was rejected.");
      if (!res.ok) {
        lastStatus = res.status;
        continue; // model missing / quota / overloaded -> try next
      }
      const j = await res.json();
      const text = (j?.candidates?.[0]?.content?.parts ?? []).map((p: any) => p?.text ?? "").join("");
      return parseJson(text);
    } catch (e) {
      if (e instanceof AiError) throw e;
      lastStatus = 502; // timeout or bad JSON -> next model
    }
  }
  throw new AiError(
    lastStatus === 429 ? 429 : 502,
    lastStatus === 429 ? "AI quota reached, wait a minute and retry." : "The AI service is unavailable right now. Please retry."
  );
}
